package com.uwb.bt2j.inspector;

import javafx.util.Pair;

public class EBWT {
	
	public EBWT() {
		
	}
	
	public static Pair<EBWT, EBWT> fromString() {
		
	}
	
	public static Pair<EBWT, EBWT> fromStrings() {
		
	}
	
	public Boolean isPacked() {
		return packed_;
	}
	
	public void szsToDisk() {
		
	}
	
	public void initFromVector() {
		
	}
	
	public double joinedLen() {
		
	}
	
	public Boolean contains() {
		
	}
	
	public final Boolean isInMemory() {
		
	}
	
	public final Boolean isEvicted() {
		
	}
	
	public void loadIntoMemory() {
		
	}
	
	public void evictFromMemory() {
		
	}
	
	public final double ftabSeqToInt() {
		
	}
	
	public final double ftabHi(double i){
		
	}
	
	public static double ftabHi() {
		
	}
	
	public static double ftabLo() {
		
	}
	
	public final double ftabLo() {
		
	}
	
	public final Boolean ftabLoHi() {
		
	}
	
	public final double tryOffset() {
		
	}
	
	public final double walkLeft() {
		
	}
	  
	public final double getOffset() {
	
	}
	
	public void postReadInit() {
		
	}
	
	public static int readFlags(final String instr) {
		
	}
	
	public final void print() {
		
	}
	
	
	public Boolean contains() {
	
	}
	
	public void joinedToTextOff(double qlen, double off, double tidx,
			  double textoff, double tlen, Boolean rejectStraddle, Boolean straddled) {
		
	}
}
