package com.uwb.bt2j.aligner.cache;

public class Reporter {
  public Boolean report(AlignmentCacheIface cache, QVal qv) {
    return true;
  }
}
