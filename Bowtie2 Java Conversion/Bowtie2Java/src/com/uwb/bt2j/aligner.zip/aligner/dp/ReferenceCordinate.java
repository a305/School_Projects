package com.uwb.bt2j.aligner.dp;
class ReferenceCoordinate {
  public static long TRefId;
  public static long TRefOff;
  
  class Coord {
    public Coord() {
      reset();
    }
    
    public void init() {
    
    }
    
    public void reset() {
    
    }
    
    public final Boolean inited() {
    
    }
    
    public final Boolean fw() {
    
    }
    
    public Boolean within() {
    
    }
    
    public long ref() {
    
    }
    
    public long off() {
    
    }
    
    public int orient() {
    
    }
    
    public void setRef() {
    
    }
    
    public void setOff() {
    
    }
    
    public void adjustOff() {
    
    }
    
    protected long ref_;
    protected long off_;
    protected int orient_;
  }
}
