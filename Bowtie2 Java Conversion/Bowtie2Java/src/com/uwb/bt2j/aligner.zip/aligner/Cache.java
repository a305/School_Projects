package com.uwb.bt2j.aligner;
class KeyValuePairs {
  class QKey {
    public long seq;
    public double len;
  
    public QKey() {
      reset();
    }
    
    public Boolean init() {
      
    }
    
    public void toString() {
      
    }
    
    public Boolean cacheable() {
      
    }
    
    public void reset() {
      
    }
  }
  
  class QVal {
    public double i_;
    public double rangen_;
    public double eltn_;
  
    public QVal() {
      reset();
    }
    
    public double offset() {
      
    }
    
    public double numRanges() {
      
    }
    
    public double numElts() {
      
    }
    
    public Boolean empty() {
      
    }
    
    public Boolean valid() {
      
    }
    
    public void reset() {
      
    }
    
    public void init() {
      
    }
    
    public void addRange() {
      
    }
  }
  
  class SAVal {
    public double topf;
    public double topb;
    public double i;
    public double len;
    
    public SAVal() {
      
    }
    
    public Boolean valid() {
      
    }
    
    public void init() {
      
    }
  }
  
  class SATuple{
    public QKey key;
    public double topf;
    public double topb;
    public TSlice offs;
  
    public SATuple() {
      reset();
    }
    
    public void init() {
      
    }
    
    public void reset() {
      
    }
    
    public void setLength() {
      
    }
    
    public doubel size() {
      
    }
  }
}
