package com.uwb.bt2j.aligner.seed;

public class Descent {

}
