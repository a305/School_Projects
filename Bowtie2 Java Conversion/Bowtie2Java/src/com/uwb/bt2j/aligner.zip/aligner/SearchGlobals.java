package com.uwb.bt2j.aligner;

public class SearchGlobals {
	public static  Boolean     gReportOverhangs;
	public static  Boolean     gNoMaqRound;
	public static  Boolean     gStrandFix;
	public static  Boolean     gRangeMode;
	public static  int      gVerbose;
	public static  int      gQuiet;
	public static  Boolean     gNofw;
	public static  Boolean     gNorc;
	public static  Boolean     gMate1fw;
	public static  Boolean     gMate2fw;
	public static  int      gMinInsert;
	public static  int      gMaxInsert;
	public static  int      gGapBarrier;
	public static  int      gAllowRedundant;
}
