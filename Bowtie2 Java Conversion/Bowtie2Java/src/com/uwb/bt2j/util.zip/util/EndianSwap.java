package com.uwb.bt2j.util;
class EndianSwap {
  public static double endianSwapU32 (double x) {
    
  }
  public static int endianSwapI32 (double x) {
    
  }
  
  public static double endianSwapI64 (double x) {
    
  }
  
  public static long endianSwapU64 (long x) {
    
  }
}
